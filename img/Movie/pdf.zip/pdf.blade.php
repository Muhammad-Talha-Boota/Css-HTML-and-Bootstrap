@extends('layouts.master_pdf')


@section('title') Dashboard Unitário
@stop

<style type="text/css">
    body {
        margin: 0px;
        padding: 0px; 
        font: 11px 'Helvetica';
        line-height: 15px;
    }
    #page_1 {
        page-break-after: always;
    }
    .address {
        padding-left:45%;
    }
    .p0 {
        margin-top: 0px;margin-bottom: 0px;
    }

    .beck {
        word-wrap: break-word;         /* All browsers since IE 5.5+ */
        overflow-wrap: break-word;     /* Renamed property in CSS3 draft spec */
        width: 100%;
    }
    td {

        /* css-3 */
        white-space: -o-pre-wrap;
        word-wrap: break-word;
        white-space: pre-wrap;
        white-space: -moz-pre-wrap;
        white-space: -pre-wrap;

    }
    table {
        table-layout: fixed;
        width: 100%;
        -moz-column-count: 2;
        -moz-column-gap: 20px;
        -webkit-column-count: 2;
        -webkit-column-gap: 20px;
        column-count: 2;
        column-gap: 20px;
        display:inline-block;
    }
    @media all and (max-width:768px) {
        .calculator tr {    display: table;  width:100%;    }
        .calculator td {    display: table-row; }
    }


</style>

@section('content')

    <div class="footer">
        Página <span class="pagenum"></span>
    </div>


<div class="x_content col-md-1">
    <div class="text-center title" style="margin-bottom:30px">{{$result[0][0]->tabela}}</div>
    <div class="clearfix"></div>
    <div class="text-center title" style="margin-bottom:30px;font-size:20px">Período de {{$dataInicial}} a {{$dataFinal}}</div>
    <div class="clearfix"></div>
    <table class="calculator beck table table-striped table-hover">

        <?php $x = 0; ?>
        @foreach ($result[1] as $row)
            @if ($x == 0)
            <!-- Titulo das colunas  -->
            <thead>
            <tr>
                @foreach ($row as $key => $value)
                    <th >{{ $key }}</th>
                @endforeach
            </tr>
            </thead>
            <tbody>
            <tr>
                <?php reset($row); ?>
                @foreach ($row as $key => $value)
                    <td>{{ $value }}</td>
                @endforeach
            </tr>
            @else
                <tr>
                    <!-- Titulo das valores  -->
                    @foreach ($row as $key => $value)
                        <td>{{ $value }}</td>
                @endforeach
                </tr>
            @endif
            <?php $x++; ?>
            @endforeach
            </tbody>
    </table>
</div>

@stop

