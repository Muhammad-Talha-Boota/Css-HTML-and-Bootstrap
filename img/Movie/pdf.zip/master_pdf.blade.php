<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <!-- Page Title -->
    <title>Test - @yield('title')</title>
    <!-- Custom Fonts -->
    <link href="http://fonts.googleapis.com/css?family=Amaranth" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
    <link href='http://fonts.googleapis.com/css?family=Roboto:100,400' rel='stylesheet' type='text/css'>

    @yield('include-css-file')

    <!-- Custom Rules -->
    <style type="text/css">
        table {
          background-color: transparent;
        }
        caption {
          padding-top: 5px;
          padding-bottom: 5px;
          color: #777777;
          text-align: center;
        }
        th {
          text-align:center;
          margin: 10%;

        }
        .table {
        text-align: center;
          margin-bottom: 20px;

        }
        .table > thead > tr > th,
        .table > tbody > tr > th,
        .table > tfoot > tr > th,
        .table > thead > tr > td,
        .table > tbody > tr > td,
        .table > tfoot > tr > td {
          padding: 1px;
          line-height: 1.42857143;
          vertical-align: top;
          border-top: 1px solid #ddd;
        }
        .table > thead > tr > th {
          vertical-align: bottom;
          border-bottom: 2px solid #ddd;
        }
        .table > caption + thead > tr:first-child > th,
        .table > colgroup + thead > tr:first-child > th,
        .table > thead:first-child > tr:first-child > th,
        .table > caption + thead > tr:first-child > td,
        .table > colgroup + thead > tr:first-child > td,
        .table > thead:first-child > tr:first-child > td {
          border-top: 0;
        }
        .table > tbody + tbody {
          border-top: 2px solid #ddd;
        }
        .table .table {
          background-color: #fff;
        }
        .table-condensed > thead > tr > th,
        .table-condensed > tbody > tr > th,
        .table-condensed > tfoot > tr > th,
        .table-condensed > thead > tr > td,
        .table-condensed > tbody > tr > td,
        .table-condensed > tfoot > tr > td {
          padding: 1px;
        }
        .table-bordered {
          border: 1px solid #ddd;
        }
        .table-bordered > thead > tr > th,
        .table-bordered > tbody > tr > th,
        .table-bordered > tfoot > tr > th,
        .table-bordered > thead > tr > td,
        .table-bordered > tbody > tr > td,
        .table-bordered > tfoot > tr > td {
          border-top: 1px solid #ddd;
          border-bottom: 1px solid #ddd;
          border-right: 1px solid #ddd;
          border-left: 1px solid #ddd;
        }
        .table-bordered > thead > tr > th,
        .table-bordered > thead > tr > td {
          border-bottom-width: 2px;
        }
        .table-striped > tbody > tr:nth-of-type(odd) {
          background-color: #f9f9f9;
        }
        .table-hover > tbody > tr:hover {
          background-color: #f5f5f5;
        }
        .table-not-bordered > thead > tr > th,
        .table-not-bordered > tbody > tr > th,
        .table-not-bordered > tfoot > tr > th,
        .table-not-bordered > thead > tr > td,
        .table-not-bordered > tbody > tr > td,
        .table-not-bordered > tfoot > tr > td {
            border: 0px;
        }

        .page-break {
            page-break-after: always;
        }

        .table { display: table; width: 100%; border-collapse: collapse; }
        .table-row { display: table-row; }
        .table-cell { display: table-cell; border: 1px solid black; padding: 1em; }

        .x_content {
            overflow: auto;
        }

        .font-13 {
            font-size: 12px;
        }
        .lato{
            font-family: 'Lato', sans-serif;
        }

        .title {
             font-family: 'Amaranth', sans-serif;
             text-transform: uppercase;
             font-size: 26px;
             color: #4F305D;
         }

        .title-info {
            font-family: 'Arial', sans-serif;
            text-transform: uppercase;
            font-size: 25px;
            color: #030205;
            padding: 5px;
        }
        .title-info-2 {
            font-family: 'Arial', sans-serif;
            text-transform: uppercase;
            font-size: 18px;
            color: #030205;
            padding-bottom: 7px;
        }
        .title-info-3 {
            font-family: 'Arial', sans-serif;
            text-transform: uppercase;
            font-size: 12px;
            color: #030205;
            padding-bottom: 7px;
        }

        .padding-20-bottom{
            padding-bottom: 30px;
        }


        .text-center {
            text-align: center;
        }
        
        .table-cabecalho{
            width:50%;
            margin-top:20px;
        }
         
        .footer {
            width: 100%;
            text-align: center;
            position: fixed;
            bottom: 0px;
        }
        .header {
            top: 0px;
        }

        .pagenum:before {
            content: counter(page);
        }

        .padding {
            display:inline-block;
            padding:10px;
        }
        .container {
            max-width:1300px;
            margin:0 auto;
        }
        .row,.column {
            box-sizing:border-box;
        }
        .row:after {
            clear:both;
        }
        .row:before,.row:after {
            display:table;
            content:" ";
        }
        .col {
            position:relative;
            /*background:#eee;*/
            margin-bottom:1em;
        }
        @media (min-width:700px) {
            .col {
                float:left;
            }
            .col+.col {
                margin-left:1.6%;
            }
            .col-xs-1 {
                width:6.86666666667%;
            }
            .col-xs-2 {
                width:15.3333333333%;
            }
            .col-xs-3 {
                width:23.8%;
            }
            .col-xs-4 {
                width:32.2666666667%;
            }
            .col-xs-5 {
                width:40.7333333333%;
            }
            .col-xs-6 {
                width:49.2%;
            }
            .col-xs-7 {
                width:57.6666666667%;
            }
            .col-xs-8 {
                width:67.7333333333%;

            }
            .col-xs-9 {
                width:74.59999999999999%;
            }
            .col-xs-10 {
                width:83.0666666667%;
            }
            .col-xs-11 {
                width:91.53333333330001%;
            }
            .col-xs-12 {
                width:100%;
            }

        }

        @media (max-width:800px) {
            .form-master {
                position: relative;
                z-index: 1;
                background: #FFFFFF;
                overflow-x: hidden;
                height: 480px;
                width: 100%;
                margin: 0 auto;
                padding: 0px;
                border-top-left-radius: 3px;
                border-top-right-radius: 3px;
                border-bottom-left-radius: 3px;
                border-bottom-right-radius: 3px;

            }
        }
        @media (min-width:801px) {
            .form-master {
                position: relative;
                z-index: 1;
                background: #FFFFFF;
                max-width: 325px;
                height: 480px;
                overflow-x: hidden;
                margin: 0 auto;
                padding: 0px;
                border-top-left-radius: 3px;
                border-top-right-radius: 3px;
                border-bottom-left-radius: 3px;
                border-bottom-right-radius: 3px;

            }

        }
                
        @yield('include-css-rule')
    </style>

</head>

<body class="nav-md">

    @yield('content')

</body>
</html>
